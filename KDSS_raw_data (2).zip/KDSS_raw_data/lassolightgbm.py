# -*- coding: utf-8 -*-
"""
Created on Wed Jun 26 18:42:57 2024

@author: user
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from imblearn.over_sampling import SMOTE
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.metrics import confusion_matrix, roc_curve, roc_auc_score, classification_report
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LassoCV, Lasso
from scipy import stats
import shap
import lightgbm as lgb

random_state = 42

# 加载数据
data = pd.read_csv("C:/Users/Administrator/Desktop/Python/ML/master/KDSS21.csv", encoding='gbk')

# 特征和标签
X = data.drop('KDSS', axis=1)
y = data['KDSS']

# 特征标准化
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 过采样处理不平衡
smote = SMOTE(sampling_strategy=0.5, random_state=random_state)
X_resampled, y_resampled = smote.fit_resample(X_scaled, y)

# 训练集测试集分割
X_train, X_test, y_train, y_test = train_test_split(X_resampled, y_resampled, test_size=0.2, random_state=random_state)

# 使用LassoCV进行特征选择
alphas = np.logspace(-4, 0, 50)
lasso_cv = LassoCV(alphas=alphas, cv=5, random_state=random_state)
lasso_cv.fit(X_train, y_train)

# 获取Lasso回归系数
lasso_coefs = lasso_cv.coef_

# 可视化Lasso回归系数
feature_names = X.columns
coefs_df = pd.DataFrame({'Feature': feature_names, 'Coefficient': lasso_coefs})
coefs_df = coefs_df[coefs_df['Coefficient'] != 0]  # 只保留系数不为零的特征
coefs_df = coefs_df.sort_values(by='Coefficient', ascending=False)

# 设置图形
plt.figure(figsize=(10, 6))

# 使用更好的颜色调色板
sns.barplot(x='Coefficient', y='Feature', data=coefs_df, palette='viridis')

# 设置标题和其他美化
plt.title('Lasso Regression Coefficients', fontsize=16)
plt.xlabel('Coefficient', fontsize=14)
plt.ylabel('Feature', fontsize=14)
plt.grid(axis='x')  # 增加x轴网格线以提高可读性
plt.tight_layout()  # 自适应图形布局

plt.show()


# 绘制LassoCV的特征选择过程折线图
alphas = np.logspace(-4, 0, 50)
coefs = []

for alpha in alphas:
    lasso = Lasso(alpha=alpha, max_iter=10000, random_state=random_state)
    lasso.fit(X_train, y_train)
    coefs.append(lasso.coef_)

plt.figure(figsize=(12, 8))
ax = plt.gca()
ax.plot(alphas, coefs)
ax.set_xscale('log')
plt.axvline(x=lasso_cv.alpha_, color='r', linestyle='--', label=f'alpha={lasso_cv.alpha_:.2e}')
plt.xlabel('Alpha')
plt.ylabel('Coefficients')
plt.title('Lasso Path', fontsize=16)
plt.legend()
plt.grid(True, which='both', linestyle='--', linewidth=0.5)
plt.tight_layout()
plt.show()

# 使用Lasso回归系数筛选特征
selected_features = coefs_df['Feature'].values
X_train_selected = X_train[:, coefs_df.index]
X_test_selected = X_test[:, coefs_df.index]

# 训练LightGBM模型
lgb_classifier = lgb.LGBMClassifier(random_state=random_state)

param_grid = {
    'n_estimators': [200],
    'learning_rate': [0.05],
    'max_depth': [7],
    'num_leaves': [30],
    'min_child_samples': [10],
    'subsample': [0.6],
    'colsample_bytree': [0.6],
    'reg_lambda': [0.1],
    'reg_alpha': [1.0]
}


# 使用GridSearchCV进行参数调优
grid_search = GridSearchCV(estimator=lgb_classifier, param_grid=param_grid, cv=5, scoring='accuracy', n_jobs=-1)
grid_search.fit(X_train_selected, y_train)

# 最佳模型
best_lgb = grid_search.best_estimator_
print(grid_search.best_estimator_)

# 预测和评估
y_pred_train = best_lgb.predict(X_train_selected)
y_pred_test = best_lgb.predict(X_test_selected)

# 计算混淆矩阵和ROC AUC
conf_matrix_train = confusion_matrix(y_train, y_pred_train)
conf_matrix_test = confusion_matrix(y_test, y_pred_test)

# 打印混淆矩阵
print("训练集混淆矩阵:\n", conf_matrix_train)
print("测试集混淆矩阵:\n", conf_matrix_test)

# 绘制混淆矩阵
def plot_confusion_matrix(conf_matrix, title='Confusion Matrix'):
    plt.figure(figsize=(8, 6))
    sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues', cbar=False, annot_kws={"size": 16}, square=True)
    
    plt.title(title, fontweight='bold', fontsize=16)
    plt.xlabel('Predicted', fontsize=14)
    plt.ylabel('Actual', fontsize=14)
    
    # 在每个格子中央显示数字
    for i in range(conf_matrix.shape[0]):
        for j in range(conf_matrix.shape[1]):
            plt.text(j + 0.5, i + 0.5, conf_matrix[i, j],
                     horizontalalignment='center',
                     verticalalignment='center',
                     color='black',
                     fontsize=16)
    
    plt.xticks(fontsize=12)
    plt.yticks(fontsize=12)
    plt.show()

# 绘制测试集混淆矩阵
plot_confusion_matrix(conf_matrix_test, title='Confusion Matrix - Test Set')


# ROC曲线
y_pred_proba_test = best_lgb.predict_proba(X_test_selected)[:, 1]
fpr, tpr, _ = roc_curve(y_test, y_pred_proba_test)
roc_auc = roc_auc_score(y_test, y_pred_proba_test)

# 绘制ROC曲线
plt.plot(fpr, tpr, label=f'ROC Curve (area = {roc_auc:.2f})')
plt.plot([0, 1], [0, 1], 'k--')
plt.legend(loc='lower right')
plt.title('LightGBM', fontweight='bold', fontsize=14)
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.show()

# 计算性能指标
def calculate_performance(conf_matrix):
    TN, FP, FN, TP = conf_matrix.ravel()
    accuracy = (TP + TN) / (TP + FP + FN + TN)
    sensitivity = TP / (TP + FN)
    specificity = TN / (TN + FP)
    PPV = TP / (TP + FP)
    NPV = TN / (TN + FN)
    PLR = sensitivity / (1 - specificity)
    NLR = (1 - sensitivity) / specificity
    return accuracy, sensitivity, specificity, PPV, NPV, PLR, NLR

acc, sens, spec, ppv, npv, plr, nlr = calculate_performance(conf_matrix_test)
print("Global accuracy:", acc)
print("Sensitivity:", sens)
print("Specificity:", spec)
print("Positive predictive value:", ppv)
print("Negative predictive value:", npv)
print("Positive likelihood ratio:", plr)
print("Negative likelihood ratio:", nlr)

# 交叉验证得分
scores = cross_val_score(lgb_classifier, X_train_selected, y_train, cv=5)
print("Average accuracy:", np.mean(scores))
print("Standard deviation:", np.std(scores))
print("Accuracy for each fold:", scores)

# 置信区间
confidence_interval = stats.t.interval(0.95, len(scores)-1, loc=np.mean(scores), scale=stats.sem(scores))
print("95% confidence interval:", confidence_interval)

# 输出F1值等评估
print(classification_report(y_test, y_pred_test))

# Convert arrays back to DataFrame for interpretability with correct column names after feature selection
X_train_selected_df = pd.DataFrame(X_train_selected, columns=selected_features)
X_test_selected_df = pd.DataFrame(X_test_selected, columns=selected_features)

# 计算SHAP值
shap.initjs()
explainer = shap.Explainer(best_lgb, X_train_selected_df)
shap_values = explainer(X_test_selected_df)

# 计算平均绝对SHAP值
shap_abs_mean = np.abs(shap_values.values).mean(axis=0)

# 创建包含特征名称和对应平均绝对SHAP值的字典
feature_importance_dict = dict(zip(X_train_selected_df.columns, shap_abs_mean))

# 对特征按照平均绝对SHAP值进行排序
sorted_feature_importance = sorted(feature_importance_dict.items(), key=lambda x: x[1], reverse=True)

# 输出排序后的特征重要性
# 输出排序后的特征重要性
for feature, importance in sorted_feature_importance:
    print(f"{feature}: {importance}")

# SHAP总结图
shap.summary_plot(shap_values, X_test_selected_df)
shap.summary_plot(shap_values, X_test_selected_df, plot_type='bar')

# SHAP依赖图
for name in X_train_selected_df.columns:
    shap.dependence_plot(name, shap_values.values, X_test_selected_df)
    
# 使用 gridspec 创建共享 y 轴的子图
fig = plt.figure(figsize=(20, 10))
gs = fig.add_gridspec(1, 2, width_ratios=[1, 1])

# 创建第一个子图 (点图)
ax1 = fig.add_subplot(gs[0])
shap.summary_plot(shap_values, X_test_selected_df, plot_type="dot", show=False)
ax1.set_title("SHAP Summary Plot (Dot)")

# 创建第二个子图 (柱状图)
ax2 = fig.add_subplot(gs[1], sharey=ax1)
shap.summary_plot(shap_values, X_test_selected_df, plot_type="bar", show=False)
ax2.set_title("SHAP Summary Plot (Bar)")

# 隐藏第二个子图的 y 轴标签
ax2.tick_params(labelleft=False)

# 调整布局
plt.tight_layout()
plt.show()




# 计算SHAP值
shap.initjs()
explainer = shap.Explainer(best_lgb, X_train_selected_df)
shap_values = explainer(X_test_selected_df)

# 计算平均绝对SHAP值
shap_abs_mean = np.abs(shap_values.values).mean(axis=0)

# 创建包含特征名称和对应平均绝对SHAP值的字典
feature_importance_dict = dict(zip(X_train_selected_df.columns, shap_abs_mean))

# 对特征按照平均绝对SHAP值进行排序
sorted_feature_importance = sorted(feature_importance_dict.items(), key=lambda x: x[1], reverse=True)

# 输出排序后的特征重要性
for feature, importance in sorted_feature_importance:
    print(f"{feature}: {importance}")

# 自定义配色
custom_palette = sns.color_palette("Set2", n_colors=2)  # 使用Set2调色板，选择两种颜色

# SHAP总结图（点图）
plt.figure(figsize=(10, 6))
shap.summary_plot(shap_values, X_test_selected_df, plot_type='dot', color=custom_palette[0])  # 自定义颜色
plt.title("SHAP Summary Plot (Dot)", fontsize=14)

# SHAP柱状图
plt.figure(figsize=(10, 6))
shap.summary_plot(shap_values, X_test_selected_df, plot_type='bar', color=custom_palette[1])  # 自定义颜色
plt.title("SHAP Summary Plot (Bar)", fontsize=14)

# SHAP依赖图
for name in X_train_selected_df.columns:
    plt.figure(figsize=(10, 6))
    shap.dependence_plot(name, shap_values.values, X_test_selected_df, show=False)
    plt.title(f"SHAP Dependence Plot: {name}", fontsize=14)
    plt.show()

# 创建共享 y 轴的子图
fig = plt.figure(figsize=(20, 10))
gs = fig.add_gridspec(1, 2, width_ratios=[1, 1])

# 创建第一个子图 (点图)
ax1 = fig.add_subplot(gs[0])
shap.summary_plot(shap_values, X_test_selected_df, plot_type="dot", show=False, color=custom_palette[0])  # 自定义颜色
ax1.set_title("SHAP Summary Plot (Dot)")

# 创建第二个子图 (柱状图)
ax2 = fig.add_subplot(gs[1], sharey=ax1)
shap.summary_plot(shap_values, X_test_selected_df, plot_type="bar", show=False, color=custom_palette[1])  # 自定义颜色
ax2.set_title("SHAP Summary Plot (Bar)")

# 隐藏第二个子图的 y 轴标签
ax2.tick_params(labelleft=False)

# 调整布局
plt.tight_layout()
plt.show()






# 17. 错判病例分析
# 确保 y_test 和 y_pred_test 是 NumPy 数组
y_test_np = np.array(y_test)
y_pred_test_np = np.array(y_pred_test)

# 提取错判病例的索引和数据
mistake_indices = np.where(y_test_np != y_pred_test_np)[0]  # 找到错判病例的索引
mistakes = X_test_selected_df.iloc[mistake_indices]  # 提取错判病例

# 错判病例分析
mistake_count = mistakes.shape[0]
total_count = X_test_selected_df.shape[0]
mistake_rate = (mistake_count / total_count) * 100

print("错判病例数量:", mistake_count)
print("错判比例: {:.2f}%".format(mistake_rate))

# 输出错判病例的详细信息
mistakes_df = pd.DataFrame(mistakes)  # 将错判病例转换为 DataFrame
mistakes_df['Actual'] = y_test_np[mistake_indices]
mistakes_df['Predicted'] = y_pred_test_np[mistake_indices]
print("错判病例详细信息:")
print(mistakes_df)

# 将错判病例详细信息保存到 Excel 文件
mistakes_df.to_excel("C:/Users/Administrator/Desktop/Python/ML/master/KDSS错判病例详细信息.xlsx", index=False)

# 假设 scaler 是用于标准化的 StandardScaler 对象
# 假设原始特征数量如下
# 假设你的 X 数据包含 13 个自变量特征
# 基础统计分析
print("\n错判病例特征描述:")
print(mistakes_df.describe())
feature_description = mistakes_df.describe()
print(feature_description)
# 将错判病例特征描述保存到 Excel 文件
feature_description.to_excel("C:/Users/Administrator/Desktop/Python/ML/master/KDSS错判病例特征描述.xlsx")

#选2个特征
# 特征分布可视化
plt.figure(figsize=(10, 6))
sns.scatterplot(data=X_test_selected_df,
                x=X_test_selected_df.columns[0],  # 第一个特征
                y=X_test_selected_df.columns[1],  # 第二个特征
                hue=y_pred_test_np,                # 预测结果
                style=y_test_np,                   # 实际结果
                palette='Set1', alpha=0.5)

# 绘制错判病例
plt.scatter(mistakes[X_test_selected_df.columns[0]], 
            mistakes[X_test_selected_df.columns[1]], 
            color='red', label='Mistakes', edgecolor='black', s=100)

plt.title('Mistakes in Predictions', fontsize=16)
plt.xlabel(X_test_selected_df.columns[0], fontsize=14)
plt.ylabel(X_test_selected_df.columns[1], fontsize=14)
plt.legend()
plt.show()

#PCA降2维
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE

# 假设 X_test_selected_df 是您已选择的模型特征 DataFrame，并且 y_pred_test_np 和 y_test_np 是预测和实际标签

# PCA 降维
pca = PCA(n_components=2)  # 降到二维
X_pca = pca.fit_transform(X_test_selected_df)

# 创建 DataFrame 便于绘图
pca_df = pd.DataFrame(data=X_pca, columns=['PC1', 'PC2'])
pca_df['Predicted'] = y_pred_test_np  # 预测结果
pca_df['Actual'] = y_test_np          # 实际结果

# 绘制降维后的散点图
plt.figure(figsize=(10, 6))
sns.scatterplot(data=pca_df, x='PC1', y='PC2', hue='Predicted', style='Actual', palette='Set1', alpha=0.5)

# 绘制错判病例
mistake_indices = np.where(y_test_np != y_pred_test_np)[0]  # 找到错判病例的索引
mistakes = X_test_selected_df.iloc[mistake_indices]         # 提取错判病例

# 在 PCA 降维后，绘制错判病例
mistakes_pca = pca.transform(mistakes)  # 将错判病例数据进行 PCA 转换
plt.scatter(mistakes_pca[:, 0], mistakes_pca[:, 1], 
            color='red', label='Mistakes', edgecolor='black', s=100)

plt.title('PCA of Test Data with Mistakes Highlighted', fontsize=16)
plt.xlabel('Principal Component 1', fontsize=14)
plt.ylabel('Principal Component 2', fontsize=14)
plt.legend()
plt.show()

#PCA降3维
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from sklearn.decomposition import PCA

# 假设 X_test_selected_df 是您已选择的模型特征 DataFrame，
# 并且 y_pred_test_np 和 y_test_np 是预测和实际标签

# PCA 降维到三维
pca = PCA(n_components=3)  # 降到三维
X_pca = pca.fit_transform(X_test_selected_df)

# 创建 DataFrame 便于绘图
pca_df = pd.DataFrame(data=X_pca, columns=['PC1', 'PC2', 'PC3'])
pca_df['Predicted'] = y_pred_test_np  # 预测结果
pca_df['Actual'] = y_test_np          # 实际结果

# 绘制降维后的三维散点图
fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(111, projection='3d')

# 绘制主体数据点
scatter = ax.scatter(pca_df['PC1'], pca_df['PC2'], pca_df['PC3'], 
                     c=pca_df['Predicted'], marker='o', alpha=0.5, cmap='Set1')

# 绘制错判病例
mistake_indices = np.where(y_test_np != y_pred_test_np)[0]  # 找到错判病例的索引
mistakes = X_test_selected_df.iloc[mistake_indices]         # 提取错判病例

# 在 PCA 降维后，绘制错判病例
mistakes_pca = pca.transform(mistakes)  # 将错判病例数据进行 PCA 转换
ax.scatter(mistakes_pca[:, 0], mistakes_pca[:, 1], mistakes_pca[:, 2], 
           color='red', label='Mistakes', edgecolor='black', s=100)

# 设置标题和标签
ax.set_title('PCA of Test Data (3D) with Mistakes Highlighted', fontsize=16)
ax.set_xlabel('Principal Component 1', fontsize=14)
ax.set_ylabel('Principal Component 2', fontsize=14)
ax.set_zlabel('Principal Component 3', fontsize=14)
ax.legend()

plt.show()


#t-SNE降2维
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.manifold import TSNE

# 假设 X_test_selected_df 是您已选择的模型特征 DataFrame，并且 y_pred_test_np 和 y_test_np 是预测和实际标签

# t-SNE 降维
tsne = TSNE(n_components=2, random_state=42)  # 设置随机状态以重现结果
X_tsne = tsne.fit_transform(X_test_selected_df)

# 创建 DataFrame 便于绘图
tsne_df = pd.DataFrame(data=X_tsne, columns=['Dim1', 'Dim2'])
tsne_df['Predicted'] = y_pred_test_np  # 预测结果
tsne_df['Actual'] = y_test_np          # 实际结果

# 计算错判病例
tsne_df['Mistake'] = tsne_df['Actual'] != tsne_df['Predicted']  # 新增列标识错判
mistake_count = tsne_df['Mistake'].sum()  # 计算错判病例的数量

# 打印错判病例数量
print(f'Number of Mistaken Cases: {mistake_count}')

# 绘制降维后的散点图
plt.figure(figsize=(10, 8))
sns.scatterplot(data=tsne_df, x='Dim1', y='Dim2', hue='Predicted', style='Actual', palette='Set1', alpha=0.5)

# 高亮错判病例
mistake_indices = np.where(tsne_df['Mistake'])[0]  # 找到错判病例的索引
plt.scatter(tsne_df.iloc[mistake_indices]['Dim1'], tsne_df.iloc[mistake_indices]['Dim2'], 
            color='red', label=f'Mistakes ({mistake_count})', edgecolor='black', s=100)

plt.title('t-SNE of Test Data with Mistakes Highlighted', fontsize=16)
plt.xlabel('Dimension 1', fontsize=14)
plt.ylabel('Dimension 2', fontsize=14)
plt.legend()
plt.show()

# 假设 X_test_selected_df 是您已选择的模型特征 DataFrame，并且 y_pred_test_np 和 y_test_np 是预测和实际标签
# 特征重要性分析
# 计算各特征在错判病例中的均值
mistake_means = mistakes_df.mean()
print("错判病例各特征均值:\n", mistake_means)

# 计算训练集的各特征均值
train_means = X_train_selected_df.mean()  # 或者 X_train_selected_df 取决于如何存储训练集

# 计算偏离均值的情况
deviation = mistake_means - train_means
print("\n错判病例特征偏离训练集均值:\n", deviation)

# 可视化偏离情况
plt.figure(figsize=(10, 8))
deviation.plot(kind='barh', color='orange')
plt.title('Deviation of Features in Mistaken Cases from Training Set Mean', fontsize=16)
plt.xlabel('Deviation', fontsize=14)
plt.ylabel('Features', fontsize=14)
plt.axvline(x=0, color='red', linestyle='--')  # 绘制均值线
plt.show()

# 错误类别分析
error_counts = mistakes_df.value_counts(subset=['Actual', 'Predicted'])
print("\n错判病例中 Actual 和 Predicted 标签的组合频数:\n", error_counts)

# 可视化错误类别组合
error_counts = error_counts.reset_index()
error_counts.columns = ['Actual', 'Predicted', 'Count']

plt.figure(figsize=(10, 8))
sns.barplot(x='Count', y='Actual', hue='Predicted', data=error_counts)
plt.title('Frequency of Actual vs Predicted in Mistaken Cases', fontsize=16)
plt.xlabel('Count', fontsize=14)
plt.ylabel('Actual', fontsize=14)
plt.legend(title='Predicted', fontsize=12)
plt.grid(True)
plt.show()



# 绘制成对特征的散点图矩阵
pairplot_data = mistakes_df[selected_features.tolist() + ['Actual']]
pairplot_data['Actual'] = pairplot_data['Actual'].map({0: 'Negative', 1: 'Positive'})  # Map classes
sns.pairplot(pairplot_data, hue='Actual', palette='Set1')
plt.suptitle('Pairplot of Mistaken Cases', y=1.02)
plt.show()

# 绘制多个特征的箱线图
selected_features = X_test_selected_df.columns[:6]  # 选择前四个特征，可以根据实际需要调整

plt.figure(figsize=(12, 12))
for i, feature in enumerate(selected_features):
    plt.subplot(2, 3, i + 1)  # 提供足够空间来展示多个图
    sns.boxplot(x='Actual', y=feature, data=mistakes_df)
    plt.title(f'Distribution of {feature} by Actual Class')
    plt.xlabel('Actual Class')
    plt.ylabel(feature)

plt.tight_layout()
plt.show()

import seaborn as sns
import matplotlib.pyplot as plt

# 选择前几个特征（例如前6个）进行多特征箱线图
selected_features = X_test_selected_df.columns[:6]  # 选择前6个特征

# 设置画布大小
plt.figure(figsize=(12, 12))

# 创建色板; self-defined colors that are friendly for sci papers
palette = sns.color_palette("Set2", n_colors=2)  # Set2 is a color palette suited for categorical data

# 绘制箱线图
for i, feature in enumerate(selected_features):
    plt.subplot(2, 3, i + 1)  # 提供足够空间来展示多个图
    sns.boxplot(x='Actual', y=feature, data=mistakes_df, palette=palette)
    plt.title(f'Distribution of {feature} by Actual Class', fontsize=14)  # 增加标题字体大小
    plt.xlabel('Actual Class', fontsize=12)  # 增加标签字体大小
    plt.ylabel(feature, fontsize=12)  # 增加y轴标签字体大小
    plt.xticks(ticks=[0, 1], labels=['KDSS', 'no KDSS'])  # 给x轴的类别添加更具体的标签

# plt.tight_layout()
plt.suptitle('Box Plots of Features by Actual Class', fontsize=16, y=0.98,fontweight='bold')  # 添加合适的标题

plt.show()





