# -*- coding: utf-8 -*-
"""
Created on Fri May 16 13:54:13 2025

@author: Administrator
"""
# 导入所需的库
import pandas as pd
import numpy as np
import statsmodels.api as sm
from statsmodels.stats.outliers_influence import variance_inflation_factor
import seaborn as sns
import matplotlib.pyplot as plt

import pandas as pd
from sklearn.impute import KNNImputer
import numpy as np

# 读取CSV文件
df = pd.read_csv("C:/Users/user/Desktop/Python/ML/master/KDSS2.csv", encoding='gbk')

# 将所有非数值的字符串值替换为NaN
df.replace(['#DIV/0!', 'NA', 'null', 'N/A', '?'], np.nan, inplace=True)

# 检查数值型数据列并尝试将其转换为浮点型
for col in df.columns:
    df[col] = pd.to_numeric(df[col], errors='coerce')

# 删除缺失值超过50%的行（你可以根据需要调整这个阈值）
df = df.dropna(thresh=df.shape[1] * 0.5)

# 选择数值型数据的列
numeric_columns = df.select_dtypes(include=[np.number]).columns.tolist()

# 使用KNNImputer填充缺失值
imputer = KNNImputer(n_neighbors=5)  # 你可以调整n_neighbors参数
df[numeric_columns] = imputer.fit_transform(df[numeric_columns])

# 将处理后的数据保存到新的CSV文件
df.to_csv("C:/Users/user/Desktop/Python/ML/master/KDSS21.csv", encoding='gbk', index=False)




# 读取数据库文件
data = pd.read_csv("C:/Users/Administrator/Desktop/Python/ML/master/KDSS31.csv",encoding='gbk')

# 使用pandas计算特征之间的相关性
correlation_matrix = data.corr()

# 使用VIF（方差膨胀因子）来分析特征共线性
features = data.drop(columns=['KDSS'])  # 假设目标变量所在的列名为'target_column'
X = sm.add_constant(features)
vif = pd.DataFrame()
vif["VIF Factor"] = [variance_inflation_factor(X.values, i) for i in range(1, X.shape[1])]
vif["features"] = features.columns

# 打印VIF结果
print(vif)

# 可视化VIF值
plt.figure(figsize=(10, 6))
sns.barplot(x='VIF Factor', y='features', data=vif, palette='viridis')

plt.title('Variance Inflation Factors (VIF)')
plt.xlabel('VIF Value')
plt.ylabel('Features')
plt.show()



# 创建示例数据集
data = pd.read_csv("C:/Users/user/Desktop/Python/ML/master/KDSS31.csv", encoding='utf-8')
# 特征和标签
X = data.drop('KDSS', axis=1)
y = data['KDSS']
df = pd.DataFrame(X)

# 计算特征之间的相关性矩阵
corr_matrix = df.corr()

# 使用seaborn绘制热图
plt.figure(figsize=(12, 10))
heatmap = sns.heatmap(corr_matrix, annot=True, cmap="viridis", fmt='.2f', linewidths=.5, cbar_kws={"shrink": .8})
plt.title('Feature Correlation Heatmap', fontsize=16)
plt.xticks(rotation=45, ha='right')
plt.yticks(rotation=0)
plt.tight_layout()  # 调整布局以防止标签被剪切
plt.show()