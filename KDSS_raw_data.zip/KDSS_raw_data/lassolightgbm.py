# -*- coding: utf-8 -*-
"""
Created on Wed Jun 26 18:42:57 2024

@author: user
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from imblearn.over_sampling import SMOTE
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.metrics import confusion_matrix, roc_curve, roc_auc_score, classification_report
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LassoCV, Lasso
from scipy import stats
import shap
import lightgbm as lgb

random_state = 42

# # 设置绘图风格
# plt.style.use('seaborn-darkgrid')
# random_state = 42
# 加载数据
data = pd.read_csv("C:/Users/Administrator/Desktop/Python/ML/master/KDSS21.csv", encoding='gbk')

# 特征和标签
X = data.drop('KDSS', axis=1)
y = data['KDSS']

# 特征标准化
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 过采样处理不平衡
smote = SMOTE(sampling_strategy=0.5, random_state=random_state)
X_resampled, y_resampled = smote.fit_resample(X_scaled, y)

# 训练集测试集分割
X_train, X_test, y_train, y_test = train_test_split(X_resampled, y_resampled, test_size=0.2, random_state=random_state)

# 输出过采样后测试集和训练集的样本数量
print("训练集样本数量:", len(y_train))
print("测试集样本数量:", len(y_test))

# 使用LassoCV进行特征选择
alphas = np.logspace(-4, 0, 50)
lasso_cv = LassoCV(alphas=alphas, cv=5, random_state=random_state)
lasso_cv.fit(X_train, y_train)

# 获取Lasso回归系数
lasso_coefs = lasso_cv.coef_

# 可视化Lasso回归系数
feature_names = X.columns
coefs_df = pd.DataFrame({'Feature': feature_names, 'Coefficient': lasso_coefs})
coefs_df = coefs_df[coefs_df['Coefficient'] != 0]  # 只保留系数不为零的特征
coefs_df = coefs_df.sort_values(by='Coefficient', ascending=False)

plt.figure(figsize=(10, 6))
sns.barplot(x='Coefficient', y='Feature', data=coefs_df)
plt.title('Lasso Regression Coefficients')
plt.show()

# 绘制LassoCV的特征选择过程折线图
alphas = np.logspace(-4, 0, 50)
coefs = []

for alpha in alphas:
    lasso = Lasso(alpha=alpha, max_iter=10000, random_state=random_state)
    lasso.fit(X_train, y_train)
    coefs.append(lasso.coef_)

plt.figure(figsize=(12, 8))
ax = plt.gca()
ax.plot(alphas, coefs)
ax.set_xscale('log')
plt.axvline(x=lasso_cv.alpha_, color='r', linestyle='--', label=f'alpha={lasso_cv.alpha_:.2e}')
plt.xlabel('Alpha')
plt.ylabel('Coefficients')
plt.title('Lasso Path', fontsize=16)
plt.legend()
plt.grid(True, which='both', linestyle='--', linewidth=0.5)
plt.tight_layout()
plt.show()

# 使用Lasso回归系数筛选特征
selected_features = coefs_df['Feature'].values
X_train_selected = X_train[:, coefs_df.index]
X_test_selected = X_test[:, coefs_df.index]

# 训练LightGBM模型
lgb_classifier = lgb.LGBMClassifier(random_state=random_state)

param_grid = {
    'n_estimators': [200],
    'learning_rate': [0.05],
    'max_depth': [7],
    'num_leaves': [30],
    'min_child_samples': [10],
    'subsample': [0.6],
    'colsample_bytree': [0.6],
    'reg_lambda': [0.1],
    'reg_alpha': [1.0]
}


# 使用GridSearchCV进行参数调优
grid_search = GridSearchCV(estimator=lgb_classifier, param_grid=param_grid, cv=5, scoring='accuracy', n_jobs=-1)
grid_search.fit(X_train_selected, y_train)

# 最佳模型
best_lgb = grid_search.best_estimator_
print(grid_search.best_estimator_)

# 预测和评估
y_pred_train = best_lgb.predict(X_train_selected)
y_pred_test = best_lgb.predict(X_test_selected)

# 计算混淆矩阵和ROC AUC
conf_matrix_train = confusion_matrix(y_train, y_pred_train)
conf_matrix_test = confusion_matrix(y_test, y_pred_test)

# 打印混淆矩阵
print("训练集混淆矩阵:\n", conf_matrix_train)
print("测试集混淆矩阵:\n", conf_matrix_test)

# 绘制混淆矩阵, , square=True
def plot_confusion_matrix(conf_matrix, title='Confusion Matrix'):
    plt.figure(figsize=(8, 6))
    sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues', cbar=False,annot_kws={"size": 16})
    
    plt.title(title, fontweight='bold', fontsize=16)
    plt.xlabel('Predicted', fontsize=14)
    plt.ylabel('Actual', fontsize=14)
    
    # 在每个格子中央显示数字
    for i in range(conf_matrix.shape[0]):
        for j in range(conf_matrix.shape[1]):
            plt.text(j + 0.5, i + 0.5, conf_matrix[i, j],
                     horizontalalignment='center',
                     verticalalignment='center',
                     color='black',
                     fontsize=16)
    
    plt.xticks(fontsize=12)
    plt.yticks(fontsize=12)
    plt.show()

# 绘制测试集混淆矩阵
plot_confusion_matrix(conf_matrix_test, title='Confusion Matrix - Test Set')


# ROC曲线
y_pred_proba_test = best_lgb.predict_proba(X_test_selected)[:, 1]
fpr, tpr, _ = roc_curve(y_test, y_pred_proba_test)
roc_auc = roc_auc_score(y_test, y_pred_proba_test)
plt.plot(fpr, tpr, label=f'ROC Curve (area = {roc_auc:.4f})')
plt.plot([0, 1], [0, 1], 'k--')
plt.legend(loc='lower right')
plt.title('RF', fontweight='bold', fontsize=14)
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.show()






# 计算性能指标
def calculate_performance(conf_matrix):
    TN, FP, FN, TP = conf_matrix.ravel()
    accuracy = (TP + TN) / (TP + FP + FN + TN)
    sensitivity = TP / (TP + FN)
    specificity = TN / (TN + FP)
    PPV = TP / (TP + FP)
    NPV = TN / (TN + FN)
    PLR = sensitivity / (1 - specificity)
    NLR = (1 - sensitivity) / specificity
    return accuracy, sensitivity, specificity, PPV, NPV, PLR, NLR

acc, sens, spec, ppv, npv, plr, nlr = calculate_performance(conf_matrix_test)
print("Global accuracy:", acc)
print("Sensitivity:", sens)
print("Specificity:", spec)
print("Positive predictive value:", ppv)
print("Negative predictive value:", npv)
print("Positive likelihood ratio:", plr)
print("Negative likelihood ratio:", nlr)

# 交叉验证得分
scores = cross_val_score(lgb_classifier, X_train_selected, y_train, cv=5)
print("Average accuracy:", np.mean(scores))
print("Standard deviation:", np.std(scores))
print("Accuracy for each fold:", scores)

# 置信区间
confidence_interval = stats.t.interval(0.95, len(scores)-1, loc=np.mean(scores), scale=stats.sem(scores))
print("95% confidence interval:", confidence_interval)

# 输出F1值等评估
print(classification_report(y_test, y_pred_test))

# Convert arrays back to DataFrame for interpretability with correct column names after feature selection
X_train_selected_df = pd.DataFrame(X_train_selected, columns=selected_features)
X_test_selected_df = pd.DataFrame(X_test_selected, columns=selected_features)

# 计算SHAP值
shap.initjs()
explainer = shap.Explainer(best_lgb, X_train_selected_df)
shap_values = explainer(X_test_selected_df)

# 计算平均绝对SHAP值
shap_abs_mean = np.abs(shap_values.values).mean(axis=0)

# 创建包含特征名称和对应平均绝对SHAP值的字典
feature_importance_dict = dict(zip(X_train_selected_df.columns, shap_abs_mean))

# 对特征按照平均绝对SHAP值进行排序
sorted_feature_importance = sorted(feature_importance_dict.items(), key=lambda x: x[1], reverse=True)

# 输出排序后的特征重要性
# 输出排序后的特征重要性
for feature, importance in sorted_feature_importance:
    print(f"{feature}: {importance}")

# SHAP总结图
shap.summary_plot(shap_values, X_test_selected_df)
shap.summary_plot(shap_values, X_test_selected_df, plot_type='bar')

# SHAP依赖图
for name in X_train_selected_df.columns:
    shap.dependence_plot(name, shap_values.values, X_test_selected_df)
    
# 使用 gridspec 创建共享 y 轴的子图
fig = plt.figure(figsize=(20, 10))
gs = fig.add_gridspec(1, 2, width_ratios=[1, 1])

# 创建第一个子图 (点图)
ax1 = fig.add_subplot(gs[0])
shap.summary_plot(shap_values, X_test_selected_df, plot_type="dot", show=False)
ax1.set_title("SHAP Summary Plot (Dot)")

# 创建第二个子图 (柱状图)
ax2 = fig.add_subplot(gs[1], sharey=ax1)
shap.summary_plot(shap_values, X_test_selected_df, plot_type="bar", show=False)
ax2.set_title("SHAP Summary Plot (Bar)")

# 隐藏第二个子图的 y 轴标签
ax2.tick_params(labelleft=False)

# 调整布局
plt.tight_layout()
plt.show()


# 计算约登指数和最优阈值
def calculate_youden_index(y_true, y_scores):
    fpr, tpr, thresholds = roc_curve(y_true, y_scores)
    youden_index = tpr - fpr  # 约登指数
    optimal_idx = np.argmax(youden_index)  # 找到最大值的索引
    optimal_threshold = thresholds[optimal_idx]
    return optimal_threshold, youden_index

# 计算测试集上的最优阈值和约登指数
optimal_threshold, youden_index = calculate_youden_index(y_test, y_pred_proba_test)

print(f'Optimal Threshold: {optimal_threshold}')
print(f'Youden Index: {max(youden_index)}')

# 根据最优阈值进行预测
y_pred_optimal = (y_pred_proba_test >= optimal_threshold).astype(int)

# 计算混淆矩阵和性能指标
conf_matrix_optimal = confusion_matrix(y_test, y_pred_optimal)
acc_optimal, sens_optimal, spec_optimal, ppv_optimal, npv_optimal, plr_optimal, nlr_optimal = calculate_performance(conf_matrix_optimal)

# 输出基于最优阈值的性能指标
print("基于最优阈值的准确率:", acc_optimal)
print("灵敏度:", sens_optimal)
print("特异性:", spec_optimal)
print("阳性预测值:", ppv_optimal)
print("阴性预测值:", npv_optimal)
print("阳性似然比:", plr_optimal)
print("阴性似然比:", nlr_optimal)

# 绘制 ROC 曲线与最优阈值
plt.plot(fpr, tpr, label=f'ROC Curve (area = {roc_auc:.4f})')
plt.plot([0, 1], [0, 1], 'k--')
plt.axvline(x=1-optimal_threshold, color='r', linestyle='--', label=f'Optimal Threshold = {optimal_threshold:.2f}')
plt.title('ROC Curve with Optimal Threshold')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.legend(loc='lower right')
plt.show()





