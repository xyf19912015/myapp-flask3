# -*- coding: utf-8 -*-
"""
Created on Sat May 17 19:14:43 2025

@author: Administrator
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.metrics import confusion_matrix, roc_curve, roc_auc_score, classification_report, precision_recall_curve, f1_score
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LassoCV, Lasso,LogisticRegression
from scipy import stats
import shap
import lightgbm as lgb
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_curve
random_state = 42
import warnings
warnings.filterwarnings("ignore", category=UserWarning)
# 设置全局样式参数
plt.rcParams['font.family'] = 'Arial'  # 使用期刊推荐的字体
plt.rcParams['axes.labelsize'] = 12
plt.rcParams['axes.titlesize'] = 14
plt.rcParams['axes.titleweight'] = 'bold'
plt.rcParams['xtick.labelsize'] = 10
plt.rcParams['ytick.labelsize'] = 10

# 加载数据
data = pd.read_csv("C:/Users/Administrator/Desktop/Python/ML/master/KDSS31.csv", encoding='gbk')

# 特征和标签
X = data.drop('KDSS', axis=1)
y = data['KDSS']

# 训练集测试集分割
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=random_state,stratify=y)

# 特征标准化
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)  # 在训练集上进行标准化
X_test_scaled = scaler.transform(X_test)  # 使用相同的参数标准化测试集

print("训练集样本数量:", len(y_train))
print("测试集样本数量:", len(y_test))
# 计算阳性样本数量
positive_train_count = sum(y_train == 1)
positive_test_count = sum(y_test == 1)

# 打印阳性样本数量
print("训练集阳性样本数量:", positive_train_count)
print("测试集阳性样本数量:", positive_test_count)
# 使用LassoCV进行特征选择
alphas = np.logspace(-4, 0, 50)
lasso_cv = LassoCV(alphas=alphas, cv=5, random_state=42)
lasso_cv.fit(X_train_scaled, y_train)

# 获取非零系数对应特征
lasso_coefs = lasso_cv.coef_
feature_names = X.columns
coefs_df = pd.DataFrame({'Feature': feature_names, 'Coefficient': lasso_coefs})
coefs_df = coefs_df[coefs_df['Coefficient'] != 0].sort_values(by='Coefficient', ascending=False)

# 绘制美化条形图
plt.figure(figsize=(8, 6))
colors = ['#1f77b4' if coef > 0 else '#d62728' for coef in coefs_df['Coefficient']]  # 正蓝负红
sns.barplot(x='Coefficient', y='Feature', data=coefs_df, palette=colors)

plt.title('Lasso Regression Coefficients', fontsize=16, fontweight='bold')
plt.xlabel('Coefficient Value', fontsize=14)
plt.ylabel('Features', fontsize=14)
plt.grid(True, axis='x', linestyle='--', alpha=0.7)
plt.axvline(x=0, color='black', linestyle='-', linewidth=1)
plt.tight_layout()
plt.show()



# 绘制 Lasso 路径图
coefs_path = []
for alpha in alphas:
    lasso = Lasso(alpha=alpha, max_iter=10000)
    lasso.fit(X_train_scaled, y_train)
    coefs_path.append(lasso.coef_)

coefs_path = np.array(coefs_path)
plt.figure(figsize=(8, 6))
for i in range(coefs_path.shape[1]):
    plt.plot(alphas, coefs_path[:, i], label=feature_names[i] if lasso_coefs[i] != 0 else None)
plt.axvline(x=lasso_cv.alpha_, color='red', linestyle='--', label=f'Optimal alpha = {lasso_cv.alpha_:.2e}')
plt.xscale('log')
plt.xlabel('Alpha', fontsize=14)
plt.ylabel('Coefficients', fontsize=14)
plt.title('Lasso Path (Coefficients vs Alpha)', fontsize=16, fontweight='bold')
plt.legend(fontsize=10, loc='upper right', ncol=2)
plt.grid(True, which='both', linestyle='--', linewidth=0.5)
plt.tight_layout()
plt.show()





# 选取特征（改为按列名选择）
selected_features = coefs_df['Feature'].values
X_train_selected = X_train_scaled[:, X.columns.get_indexer(selected_features)]
X_test_selected = X_test_scaled[:, X.columns.get_indexer(selected_features)]

# 样本不平衡处理
pos_weight = (len(y_train) - sum(y_train)) / sum(y_train)

# LightGBM模型
lgb_classifier = lgb.LGBMClassifier(random_state=42, scale_pos_weight=pos_weight,class_weight='balanced')


# LightGBM模型
lgb_classifier = lgb.LGBMClassifier(random_state=42)

param_grid = {
    'n_estimators': [200],
    'learning_rate': [0.05],
    'max_depth': [7],
    'num_leaves': [30],
    'min_child_samples': [10],
    'subsample': [0.6],
    'colsample_bytree': [0.6],
    'reg_lambda': [0.1],
    'reg_alpha': [1.0],
    # 'scale_pos_weight': [5]
}

grid_search = GridSearchCV(estimator=lgb_classifier, param_grid=param_grid, cv=5, scoring='accuracy', n_jobs=-1)
grid_search.fit(X_train_selected, y_train)
best_lgb = grid_search.best_estimator_
print(best_lgb)

# 预测
y_pred_train = best_lgb.predict(X_train_selected)
y_pred_test = best_lgb.predict(X_test_selected)

# 混淆矩阵（加上标签）
conf_matrix_train = confusion_matrix(y_train, y_pred_train, labels=[0, 1])
conf_matrix_test = confusion_matrix(y_test, y_pred_test, labels=[0, 1])

print("训练集混淆矩阵:\n", conf_matrix_train)
print("测试集混淆矩阵:\n", conf_matrix_test)

# 绘制混淆矩阵
def plot_confusion_matrix(conf_matrix, title='Confusion Matrix'):
    plt.figure(figsize=(8, 6))
    sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues', cbar=False, annot_kws={"size": 16})
    plt.title(title, fontweight='bold', fontsize=16)
    plt.xlabel('Predicted', fontsize=14)
    plt.ylabel('Actual', fontsize=14)
    plt.xticks(fontsize=12)
    plt.yticks(fontsize=12)
    plt.show()

plot_confusion_matrix(conf_matrix_test, title='Confusion Matrix - Test Set')

# ROC曲线：训练集和测试集叠加
y_pred_proba_train = best_lgb.predict_proba(X_train_selected)[:, 1]  # 获取训练集预测概率
y_pred_proba_test = best_lgb.predict_proba(X_test_selected)[:, 1]  # 获取测试集预测概率

fpr_train, tpr_train, _ = roc_curve(y_train, y_pred_proba_train)
roc_auc_train = roc_auc_score(y_train, y_pred_proba_train)

fpr_test, tpr_test, _ = roc_curve(y_test, y_pred_proba_test)
roc_auc_test = roc_auc_score(y_test, y_pred_proba_test)

# 绘制ROC曲线
plt.figure(figsize=(8, 6))
plt.plot(fpr_train, tpr_train, color='blue', lw=2, label=f'Train ROC curve (AUC = {roc_auc_train:.4f})')
plt.plot(fpr_test, tpr_test, color='red', lw=2, label=f'Test ROC curve (AUC = {roc_auc_test:.4f})')
plt.plot([0, 1], [0, 1], 'k--', lw=2)  # 对角线（随机猜测）

# 添加标题、坐标轴标签和图例
plt.xlabel('False Positive Rate', fontsize=14)
plt.ylabel('True Positive Rate', fontsize=14)
plt.title('LightGBM ROC Curve', fontsize=16, fontweight='bold')
plt.legend(loc='lower right', fontsize=12)
plt.grid(True, linestyle='--', linewidth=0.5)
plt.tight_layout()
plt.show()

# 计算性能指标
def calculate_performance(conf_matrix):
    TN, FP, FN, TP = conf_matrix.ravel()
    accuracy = (TP + TN) / (TP + FP + FN + TN)
    sensitivity = TP / (TP + FN) if (TP + FN) > 0 else 0
    specificity = TN / (TN + FP) if (TN + FP) > 0 else 0
    PPV = TP / (TP + FP) if (TP + FP) > 0 else 0
    NPV = TN / (TN + FN) if (TN + FN) > 0 else 0
    PLR = sensitivity / (1 - specificity) if (1 - specificity) > 0 else 0
    NLR = (1 - sensitivity) / specificity if specificity > 0 else 0
    return accuracy, sensitivity, specificity, PPV, NPV, PLR, NLR

# 输出测试集性能
acc, sens, spec, ppv, npv, plr, nlr = calculate_performance(conf_matrix_test)
print("Global accuracy:", acc)
print("Sensitivity:", sens)
print("Specificity:", spec)
print("Positive predictive value:", ppv)
print("Negative predictive value:", npv)
print("Positive likelihood ratio:", plr)
print("Negative likelihood ratio:", nlr)

# 交叉验证
scores = cross_val_score(lgb_classifier, X_train_selected, y_train, cv=5)
print("Average accuracy:", np.mean(scores))
print("Standard deviation:", np.std(scores))
print("Accuracy for each fold:", scores)

# 置信区间
confidence_interval = stats.t.interval(0.95, len(scores)-1, loc=np.mean(scores), scale=stats.sem(scores))
print("95% confidence interval:", confidence_interval)

# 分类报告
print(classification_report(y_test, y_pred_test, labels=[0, 1]))

import numpy as np
from sklearn.metrics import roc_curve, confusion_matrix, f1_score

# 计算约登指数和最优阈值
def calculate_youden_index(y_true, y_scores):
    # 计算ROC曲线的假阳性率（fpr）和真正率（tpr）
    fpr, tpr, thresholds = roc_curve(y_true, y_scores)
    
    # 计算Youden指数 (Youden's J statistic)
    youden_index = tpr - fpr
    
    # 找到使Youden指数最大的阈值
    optimal_idx = np.argmax(youden_index)
    optimal_threshold = thresholds[optimal_idx]
    
    return optimal_threshold, youden_index

# 计算最优阈值（Youden指数）和约登指数
optimal_threshold_youden, youden_index = calculate_youden_index(y_test, y_pred_proba_test)

# 输出最优阈值和Youden指数
print(f'Optimal Threshold (Youden): {optimal_threshold_youden:.4f}')
print(f'Youden Index: {max(youden_index):.4f}')

# 基于最优阈值进行预测
y_pred_optimal_youden = (y_pred_proba_test >= optimal_threshold_youden).astype(int)

# 计算混淆矩阵和其他性能指标
conf_matrix_optimal = confusion_matrix(y_test, y_pred_optimal_youden, labels=[0, 1])

# 计算性能指标（如准确率，灵敏度，特异性等）
acc_opt, sens_opt, spec_opt, ppv_opt, npv_opt, plr_opt, nlr_opt = calculate_performance(conf_matrix_optimal)

# 输出基于最优阈值的评估指标
print("基于最优阈值的准确率:", acc_opt)
print("灵敏度:", sens_opt)
print("特异性:", spec_opt)
print("阳性预测值:", ppv_opt)
print("阴性预测值:", npv_opt)
print("阳性似然比:", plr_opt)
print("阴性似然比:", nlr_opt)






import shap
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np


# 计算SHAP值
X_train_selected_df = pd.DataFrame(X_train_selected, columns=selected_features)
X_test_selected_df = pd.DataFrame(X_test_selected, columns=selected_features)

# 使用 TreeExplainer
explainer = shap.TreeExplainer(best_lgb)

shap_values = explainer.shap_values(X_test_selected_df)


# 计算 SHAP 值时确保使用的是测试集
shap_values = explainer.shap_values(X_test_selected_df)  # 确保 X_test_selected_df 是测试集的特征

# 确保处理的是正类的 SHAP 值（假设第二个类别是正类）
if isinstance(shap_values, list):
    shap_values_positive = shap_values[1]  # 如果是列表，使用正类的SHAP值
else:
    shap_values_positive = shap_values  # 如果是矩阵，直接使用

# 检查 SHAP 值的形状和数据特征形状
print(f"SHAP values shape: {shap_values_positive.shape}")
print(f"X_test_selected_df shape: {X_test_selected_df.shape}")

# 可视化：SHAP 总结图
shap.summary_plot(shap_values_positive, X_test_selected_df)

# 计算平均绝对 SHAP 值
shap_abs_mean = np.abs(shap_values_positive).mean(axis=0)

# 创建包含特征名称和对应平均绝对SHAP值的字典
feature_importance_dict = dict(zip(X_test_selected_df.columns, shap_abs_mean))

# 对特征按照平均绝对SHAP值进行排序
sorted_feature_importance = sorted(feature_importance_dict.items(), key=lambda x: x[1], reverse=True)

# 输出排序后的特征重要性
print("\n### 特征重要性 (基于 SHAP 值)：###")
for feature, importance in sorted_feature_importance:
    print(f"{feature}: {importance:.4f}")

# 自定义配色
custom_palette = sns.color_palette("Set2", n_colors=2)  # 自定义颜色调色板

# SHAP总结图（点图）
plt.figure(figsize=(10, 6))
shap.summary_plot(shap_values_positive, X_test_selected_df, plot_type='dot', color=custom_palette[0])  
plt.title("SHAP Summary Plot (Dot)", fontsize=14)

# SHAP柱状图
plt.figure(figsize=(10, 6))
shap.summary_plot(shap_values_positive, X_test_selected_df, plot_type='bar', color=custom_palette[1])  
plt.title("SHAP Summary Plot (Bar)", fontsize=14)

# SHAP依赖图
print("\n### SHAP依赖图：###")
for name in X_test_selected_df.columns[:5]:  # 示例：绘制前三个特征的依赖图
    plt.figure(figsize=(10, 6))
    shap.dependence_plot(name, shap_values_positive, X_test_selected_df, show=False)  
    plt.title(f"SHAP Dependence Plot: {name}", fontsize=14)
    plt.show()

# 创建共享 y 轴的子图
fig = plt.figure(figsize=(20, 10))
gs = fig.add_gridspec(1, 2, width_ratios=[1, 1])

# 共享y轴：绘制两个子图
# 第一子图 (Dot 图)
ax1 = fig.add_subplot(gs[0])
shap.summary_plot(shap_values_positive, X_test_selected_df, plot_type="dot", show=False, color=custom_palette[0])  
ax1.set_title("SHAP Summary Plot (Dot)", fontsize=16)

# 第二子图 (Bar 图)
ax2 = fig.add_subplot(gs[1], sharey=ax1)
shap.summary_plot(shap_values_positive, X_test_selected_df, plot_type="bar", show=False, color=custom_palette[1])  
ax2.set_title("SHAP Summary Plot (Bar)", fontsize=16)

# 隐藏第二子图的 y 轴标签
ax2.tick_params(labelleft=False)

# 调整布局
plt.tight_layout()
plt.show()
# 错判病例分析
# 提取错判样本索引和数据
y_test_np = np.array(y_test)           # 转换为 np.array
y_pred_test_np = np.array(y_pred_test)
mistake_indices = np.where(y_test_np != y_pred_test_np)[0]  # 找到错判病例索引
mistakes = X_test_selected_df.iloc[mistake_indices]         # 错判样本数据

# 错判病例统计
mistake_count = mistakes.shape[0]      # 错判数量
total_count = X_test_selected_df.shape[0]
mistake_rate = (mistake_count / total_count) * 100          # 错误率

print("\n### 错判病例分析：###")
print("错判病例数量:", mistake_count)
print(f"错判率: {mistake_rate:.2f}%")

# 输出错判样本详细信息
print("\n错判病例详细信息：")
mistakes_df = pd.DataFrame(mistakes)
mistakes_df['Actual'] = y_test_np[mistake_indices]
mistakes_df['Predicted'] = y_pred_test_np[mistake_indices]
print(mistakes_df)

# 错误分析 - 保存到Excel
excel_path_mistakes = "C:/Users/Administrator/Desktop/Python/ML/master/KDSS错判病例详细信息.xlsx"
mistakes_df.to_excel(excel_path_mistakes, index=False)
print(f"错判病例详细信息已保存到 {excel_path_mistakes}")

# 错判病例特征统计分析
print("\n### 错判病例特征描述：###")
mistakes_description = mistakes.describe()
excel_path_description = "C:/Users/Administrator/Desktop/Python/ML/master/KDSS错判病例特征描述.xlsx"
mistakes_description.to_excel(excel_path_description)
print(f"错判病例特征描述已保存到 {excel_path_description}")

# 错误类别的分布
error_counts = mistakes_df.value_counts(subset=['Actual', 'Predicted'])
print("\n### 错误类别分布：###")
print(error_counts)

# 错判病例特征偏离分析
print("\n### 错判病例特征偏离分析：###")
train_means = X_train_selected_df.mean()  # 训练集特征均值
mistake_means = mistakes_df.mean()        # 错判样本特征均值
deviation = mistake_means - train_means   # 偏差

# 可视化错判特征的偏离
plt.figure(figsize=(10, 10))
deviation.plot(kind='barh', color='orange')
plt.title('Deviation of Mistaken Cases from Training Mean')
plt.xlabel('Deviation Value', fontsize=14)
plt.ylabel('Features', fontsize=14)
plt.axvline(x=0, color='red', linestyle='--', label='Baseline')
plt.legend()
plt.tight_layout()
plt.show()

# 特征分布散点图（选取2个特征对错判分析）
plt.figure(figsize=(8, 8))
sns.scatterplot(data=X_test_selected_df,
                x=X_test_selected_df.columns[0], 
                y=X_test_selected_df.columns[1], 
                hue=y_pred_test_np, 
                style=y_test_np, 
                palette='Set1', alpha=0.6)
plt.scatter(mistakes[X_test_selected_df.columns[0]], 
            mistakes[X_test_selected_df.columns[1]], 
            color='red', label='Mistakes', edgecolor='black', s=100)
plt.title('Mistaken Cases (Selected Two Features)', fontsize=16)
plt.xlabel(X_test_selected_df.columns[0], fontsize=14)
plt.ylabel(X_test_selected_df.columns[1], fontsize=14)
plt.grid(True, alpha=0.5)
plt.legend()
plt.tight_layout()
plt.show()


















