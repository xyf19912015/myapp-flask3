# -*- coding: utf-8 -*-
"""
Created on Wed May 14 16:52:16 2025

@author: Administrator
"""
# -*- coding: utf-8 -*-
"""
Created on Fri Jun 21 21:00:42 2024

@author: user
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.metrics import confusion_matrix, roc_curve, roc_auc_score, classification_report
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LassoCV, Lasso, LogisticRegression
from scipy import stats
import shap

# 加载数据
data = pd.read_csv("C:/Users/Administrator/Desktop/Python/ML/master/KDSS21.csv", encoding='gbk')

# 特征和标签
X = data.drop('KDSS', axis=1)
y = data['KDSS']

# 特征标准化
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 训练集测试集分割
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# 输出分割后训练集和测试集的样本数量
print("训练集样本数量:", len(y_train))
print("测试集样本数量:", len(y_test))

# 使用LassoCV进行特征选择
alphas = np.logspace(-4, 0, 50)
lasso_cv = LassoCV(alphas=alphas, cv=5, random_state=42)
lasso_cv.fit(X_train, y_train)

# 获取Lasso回归系数
lasso_coefs = lasso_cv.coef_

# 可视化Lasso回归系数
feature_names = X.columns
coefs_df = pd.DataFrame({'Feature': feature_names, 'Coefficient': lasso_coefs})
coefs_df = coefs_df[coefs_df['Coefficient'] != 0]  # 只保留系数不为零的特征
coefs_df = coefs_df.sort_values(by='Coefficient', ascending=False)

plt.figure(figsize=(10, 6))
sns.barplot(x='Coefficient', y='Feature', data=coefs_df)
plt.title('Lasso Regression Coefficients')
plt.show()

# 绘制Lasso路径图
alphas = np.logspace(-4, 0, 50)
coefs = []

for alpha in alphas:
    lasso = Lasso(alpha=alpha, max_iter=10000)
    lasso.fit(X_train, y_train)
    coefs.append(lasso.coef_)

plt.figure(figsize=(12, 8))
ax = plt.gca()
ax.plot(alphas, coefs)
ax.set_xscale('log')
plt.axvline(x=lasso_cv.alpha_, color='r', linestyle='--', label=f'alpha={lasso_cv.alpha_:.2e}')
plt.xlabel('Alpha')
plt.ylabel('Coefficients')
plt.title('Lasso Path')
plt.legend()
plt.grid(True, which='both', linestyle='--', linewidth=0.5)
plt.tight_layout()
plt.show()

# 使用LassoCV系数筛选特征
selected_features = coefs_df['Feature'].values
X_train_selected = X_train[:, coefs_df.index]
X_test_selected = X_test[:, coefs_df.index]

# 替换为逻辑回归模型初始化
logistic_classifier = LogisticRegression(max_iter=1000)
best_logistic = logistic_classifier.fit(X_train_selected, y_train)
print(best_logistic)

# 逻辑回归系数作为特征重要性
feature_importances = np.abs(best_logistic.coef_[0])
sns.barplot(x=feature_importances, y=selected_features)
plt.title('Feature Importances')
plt.show()

# 预测和评估
y_pred_train = best_logistic.predict(X_train_selected)
y_pred_test = best_logistic.predict(X_test_selected)

conf_matrix_train = confusion_matrix(y_train, y_pred_train)
conf_matrix_test = confusion_matrix(y_test, y_pred_test)
print("训练集混淆矩阵:\n", conf_matrix_train)
print("测试集混淆矩阵:\n", conf_matrix_test)

# 绘制混淆矩阵
def plot_confusion_matrix(conf_matrix, title='Confusion Matrix'):
    plt.figure(figsize=(8, 6))
    sns.heatmap(conf_matrix, annot=False, fmt='d', cmap='Blues', cbar=False)
    plt.title(title, fontweight='bold', fontsize=16)
    plt.xlabel('Predicted', fontsize=14)
    plt.ylabel('Actual', fontsize=14)

    for i in range(conf_matrix.shape[0]):
        for j in range(conf_matrix.shape[1]):
            plt.text(j + 0.5, i + 0.5, conf_matrix[i, j], 
                     horizontalalignment='center', 
                     verticalalignment='center', 
                     color='black', 
                     fontsize=14)
    
    plt.xticks(np.arange(conf_matrix.shape[1]) + 0.5, np.arange(conf_matrix.shape[1]), fontsize=12)
    plt.yticks(np.arange(conf_matrix.shape[0]) + 0.5, np.arange(conf_matrix.shape[0]), fontsize=12)
    plt.show()

# 绘制测试集混淆矩阵
plot_confusion_matrix(conf_matrix_test, title='Confusion Matrix - Test Set')

# ROC曲线
y_pred_proba_test = best_logistic.predict_proba(X_test_selected)[:, 1]
fpr, tpr, _ = roc_curve(y_test, y_pred_proba_test)
roc_auc = roc_auc_score(y_test, y_pred_proba_test)

plt.plot(fpr, tpr, label=f'ROC Curve (area = {roc_auc:.2f})')
plt.plot([0, 1], [0, 1], 'k--')
plt.legend(loc='lower right')
plt.title('Logistic Regression ROC Curve', fontweight='bold', fontsize=14)
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.show()

# 计算性能指标
def calculate_performance(conf_matrix):
    TN, FP, FN, TP = conf_matrix.ravel()
    accuracy = (TP + TN) / (TP + FP + FN + TN)
    sensitivity = TP / (TP + FN)
    specificity = TN / (TN + FP)
    PPV = TP / (TP + FP)
    NPV = TN / (TN + FN)
    PLR = sensitivity / (1 - specificity)
    NLR = (1 - sensitivity) / specificity
    return accuracy, sensitivity, specificity, PPV, NPV, PLR, NLR

acc, sens, spec, ppv, npv, plr, nlr = calculate_performance(conf_matrix_test)
print("Global accuracy:", acc)
print("Sensitivity:", sens)
print("Specificity:", spec)
print("Positive predictive value:", ppv)
print("Negative predictive value:", npv)
print("Positive likelihood ratio:", plr)
print("Negative likelihood ratio:", nlr)

# 交叉验证
scores = cross_val_score(logistic_classifier, X_train_selected, y_train, cv=5)
print("Average accuracy:", np.mean(scores))
print("Standard deviation:", np.std(scores))
print("Accuracy for each fold:", scores)

# 置信区间
confidence_interval = stats.t.interval(0.95, len(scores) - 1, loc=np.mean(scores), scale=stats.sem(scores))
print("95% confidence interval:", confidence_interval)

# 输出F1等评估指标
print(classification_report(y_test, y_pred_test))

# 计算SHAP值
X_train_selected_df = pd.DataFrame(X_train_selected, columns=selected_features)
X_test_selected_df = pd.DataFrame(X_test_selected, columns=selected_features)

explainer = shap.Explainer(best_logistic, X_train_selected_df)
shap_values = explainer(X_test_selected_df)

# SHAP总结图
shap.summary_plot(shap_values, X_test_selected_df)
shap.summary_plot(shap_values, X_test_selected_df, plot_type='bar')