# -*- coding: utf-8 -*-
"""
Created on Fri Jun 21 21:20:12 2024

@author: user
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.metrics import confusion_matrix, roc_curve, roc_auc_score, classification_report
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LassoCV, Lasso
from sklearn.ensemble import RandomForestClassifier
from scipy import stats
import shap

random_state = 42

# 设置全局样式参数
plt.rcParams['font.family'] = 'Arial'  # 使用期刊推荐的字体
plt.rcParams['axes.labelsize'] = 12
plt.rcParams['axes.titlesize'] = 14
plt.rcParams['axes.titleweight'] = 'bold'
plt.rcParams['xtick.labelsize'] = 10
plt.rcParams['ytick.labelsize'] = 10
# 加载数据
data = pd.read_csv("C:/Users/Administrator/Desktop/Python/ML/master/KDSS31.csv", encoding='gbk')

# 特征和标签
X = data.drop('KDSS', axis=1)
y = data['KDSS']

# 训练集和测试集分割
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=random_state,stratify=y)

# 特征标准化
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)  # 在训练集上进行标准化
X_test_scaled = scaler.transform(X_test)  # 使用相同的参数标准化测试集

# 使用LassoCV进行特征选择
alphas = np.logspace(-4, 0, 50)
lasso_cv = LassoCV(alphas=alphas, cv=5, random_state=random_state)
lasso_cv.fit(X_train_scaled, y_train)

# 获取Lasso回归系数
lasso_coefs = lasso_cv.coef_

# 可视化Lasso回归系数
feature_names = X.columns
coefs_df = pd.DataFrame({'Feature': feature_names, 'Coefficient': lasso_coefs})
coefs_df = coefs_df[coefs_df['Coefficient'] != 0]  # 只保留系数不为零的特征
coefs_df = coefs_df.sort_values(by='Coefficient', ascending=False)

plt.figure(figsize=(10, 6))
sns.barplot(x='Coefficient', y='Feature', data=coefs_df)
plt.title('Lasso Regression Coefficients')
plt.show()

# 使用LassoCV系数筛选特征
selected_features = coefs_df['Feature'].values
X_train_selected = X_train_scaled[:, coefs_df.index]
X_test_selected = X_test_scaled[:, coefs_df.index]

# 使用class_weight='balanced'的随机森林分类器初始化
rf_classifier = RandomForestClassifier(random_state=random_state, class_weight='balanced')

# 网格搜索的参数网格
param_grid = {
    'n_estimators': [200],  # 尝试不同数量的决策树
    'max_depth': [5],  # 调整树的最大深度
    'min_samples_split': [4],  # 调整内部节点再划分所需最小样本数
    'min_samples_leaf': [2],  # 调整叶子结点最小样本数
    'max_features': ['sqrt'],  # 最大特征数
    'bootstrap': [True],  # 是否使用自助法
    'max_samples': [0.9]  # 每棵树中使用的最大训练样本比例
}

grid_search = GridSearchCV(estimator=rf_classifier, param_grid=param_grid, cv=5, scoring='accuracy', n_jobs=-1)
grid_search.fit(X_train_selected, y_train)

# 最佳模型
best_rf = grid_search.best_estimator_
print(best_rf)

# 特征重要性
feature_importances = best_rf.feature_importances_
sns.barplot(x=feature_importances, y=selected_features, orient='h')
plt.title('Feature Importances')
plt.show()

# 预测和评估
y_pred_train = best_rf.predict(X_train_selected)
y_pred_test = best_rf.predict(X_test_selected)
conf_matrix_train = confusion_matrix(y_train, y_pred_train)
conf_matrix_test = confusion_matrix(y_test, y_pred_test)
print("训练集混淆矩阵:\n", conf_matrix_train)
print("测试集混淆矩阵:\n", conf_matrix_test)

# 绘制混淆矩阵
def plot_confusion_matrix(conf_matrix, title='Confusion Matrix'):
    plt.figure(figsize=(8, 6))
    sns.heatmap(conf_matrix, annot=False, fmt='d', cmap='Blues', cbar=False)
    
    plt.title(title, fontweight='bold', fontsize=16)
    plt.xlabel('Predicted', fontsize=14)
    plt.ylabel('Actual', fontsize=14)
    
    # 在每个格子中央显示数字
    for i in range(conf_matrix.shape[0]):
        for j in range(conf_matrix.shape[1]):
            plt.text(j + 0.5, i + 0.5, conf_matrix[i, j],
                      horizontalalignment='center',
                      verticalalignment='center',
                      color='black',
                      fontsize=16)
    
    plt.xticks(fontsize=12)
    plt.yticks(fontsize=12)
    plt.show()

# 绘制测试集混淆矩阵
plot_confusion_matrix(conf_matrix_test, title='Confusion Matrix - Test Set')

# ROC曲线：训练集和测试集叠加
y_pred_proba_train = best_rf.predict_proba(X_train_selected)[:, 1]  # 获取训练集预测概率
y_pred_proba_test = best_rf.predict_proba(X_test_selected)[:, 1]  # 获取测试集预测概率

fpr_train, tpr_train, _ = roc_curve(y_train, y_pred_proba_train)
roc_auc_train = roc_auc_score(y_train, y_pred_proba_train)

fpr_test, tpr_test, _ = roc_curve(y_test, y_pred_proba_test)
roc_auc_test = roc_auc_score(y_test, y_pred_proba_test)

# 绘制ROC曲线
plt.figure(figsize=(8, 6))
plt.plot(fpr_train, tpr_train, color='blue', lw=2, label=f'Train ROC curve (AUC = {roc_auc_train:.4f})')
plt.plot(fpr_test, tpr_test, color='red', lw=2, label=f'Test ROC curve (AUC = {roc_auc_test:.4f})')
plt.plot([0, 1], [0, 1], 'k--', lw=2)  # 对角线（随机猜测）

# 添加标题、坐标轴标签和图例
plt.xlabel('False Positive Rate', fontsize=14)
plt.ylabel('True Positive Rate', fontsize=14)
plt.title('RF ROC Curve', fontsize=16, fontweight='bold')
plt.legend(loc='lower right', fontsize=12)
plt.grid(True, linestyle='--', linewidth=0.5)
plt.tight_layout()
plt.show()

# 计算性能指标
def calculate_performance(conf_matrix):
    TN, FP, FN, TP = conf_matrix.ravel()
    accuracy = (TP + TN) / (TP + FP + FN + TN)
    sensitivity = TP / (TP + FN) if (TP + FN) > 0 else 0
    specificity = TN / (TN + FP) if (TN + FP) > 0 else 0
    PPV = TP / (TP + FP) if (TP + FP) > 0 else 0
    NPV = TN / (TN + FN) if (TN + FN) > 0 else 0
    PLR = sensitivity / (1 - specificity) if (1 - specificity) > 0 else 0
    NLR = (1 - sensitivity) / specificity if specificity > 0 else 0
    return accuracy, sensitivity, specificity, PPV, NPV, PLR, NLR

# 计算测试集性能
acc, sens, spec, ppv, npv, plr, nlr = calculate_performance(conf_matrix_test)
print("Global accuracy:", acc)
print("Sensitivity:", sens)
print("Specificity:", spec)
print("Positive predictive value:", ppv)
print("Negative predictive value:", npv)
print("Positive likelihood ratio:", plr)
print("Negative likelihood ratio:", nlr)

# 交叉验证
scores = cross_val_score(best_rf, X_train_selected, y_train, cv=5)
print("Average accuracy:", np.mean(scores))
print("Standard deviation:", np.std(scores))
print("Accuracy for each fold:", scores)

# 置信区间
confidence_interval = stats.t.interval(0.95, len(scores)-1, loc=np.mean(scores), scale=stats.sem(scores))
print("95% confidence interval:", confidence_interval)

# 输出F1值等评估指标
print(classification_report(y_test, y_pred_test))

# 计算SHAP值
X_train_selected_df = pd.DataFrame(X_train_selected, columns=selected_features)
X_test_selected_df = pd.DataFrame(X_test_selected, columns=selected_features)

# 使用SHAP解释器，并关闭加性检查
explainer = shap.Explainer(best_rf, X_train_selected_df)
shap_values = explainer(X_test_selected_df, check_additivity=False)

# SHAP总结图
shap.summary_plot(shap_values.values, X_test_selected_df)
shap.summary_plot(shap_values.values, X_test_selected_df, plot_type='bar')